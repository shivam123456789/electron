import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-items',
  templateUrl: './stock-items.component.html',
  styleUrls: ['./stock-items.component.scss']
})
export class StockItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
